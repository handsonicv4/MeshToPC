	This program can be used to generate point cloud from 3d model (nearly all main stream format!)
	It's depend on model import library Assimp, so do not remove .dll file

	Usage: meshtopc.exe [input model file] [output text file] [point number upper bound]
	Set [point number upper bound] to generate fewer/sparser point cloud
	Or with full detial

    Output text format: one point each line with x,y,z order
														--Author Sentao Li
															sentaoli@usc.edu